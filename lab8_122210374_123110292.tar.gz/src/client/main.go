package main

import (
	"bufio"
	"encoding/gob"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"

	"github.com/fsnotify/fsnotify"
)

type Client struct {
	mu      sync.RWMutex
	hashMap map[int]string
}

type TrackerRequest struct {
	Type        string
	StoreHashes []int
	Hash        int
	FilePath    string
	Resp        chan TrackerResponse
}

type TrackerResponse struct {
	IPs []string
	Err error
}

func NewClient(hm map[int]string) *Client {
	return &Client{
		hashMap: hm,
	}
}

func readFile(filePath string) ([]byte, error) {
	data, err := os.ReadFile(filePath)
	if err != nil {
		fmt.Printf("Error reading file %s: %v", filePath, err)
		return nil, err
	}
	return data, nil
}

func sum(filePath string) (int, error) {
	data, err := readFile(filePath)
	if err != nil {
		return 0, err
	}

	_sum := 0
	for _, b := range data {
		_sum += int(b)
	}

	return _sum, nil
}

func listarArquivos(diretorio string) []string {
	arquivos, err := os.ReadDir(diretorio)
	if err != nil {
		log.Fatal(err)
	}

	var result []string
	for _, arquivo := range arquivos {
		if !arquivo.IsDir() {
			result = append(result, arquivo.Name())
		}
	}
	return result
}

func generateFilesHashMap(diretorio string) (map[string][]int, map[int]string) {
	if _, err := os.Stat(diretorio); os.IsNotExist(err) {
		log.Fatalf("O diretório %s não existe", diretorio)
	}
	files := listarArquivos(diretorio)

	hashs := make(map[string][]int)
	fps := make(map[int]string)
	for _, name := range files {
		fp := filepath.Join(diretorio, name)
		fileSum, err := sum(fp)
		if err != nil {
			fileSum = 0
		}
		fps[fileSum] = fp

		hashs[fp] = append(hashs[fp], fileSum)
	}

	return hashs, fps
}

func runTrackerConnection(conn net.Conn, reqChan <-chan TrackerRequest) {
	defer conn.Close()
	encoder := gob.NewEncoder(conn)
	decoder := gob.NewDecoder(conn)
	for req := range reqChan {
		switch req.Type {
		case "store":
			if err := encoder.Encode("store"); err != nil {
				log.Println("Error encoding request type:", err)
				if req.Resp != nil {
					req.Resp <- TrackerResponse{Err: err}
					close(req.Resp)
				}
				continue
			}
			if err := encoder.Encode(req.StoreHashes); err != nil {
				log.Println("Error encoding hashes:", err)
				if req.Resp != nil {
					req.Resp <- TrackerResponse{Err: err}
					close(req.Resp)
				}
				continue
			}
			fmt.Println("Initial hashes stored.")
			if req.Resp != nil {
				req.Resp <- TrackerResponse{}
				close(req.Resp)
			}
		case "create", "delete":
			if err := encoder.Encode(req.Type); err != nil {
				log.Println("Error encoding action:", err)
				if req.Resp != nil {
					req.Resp <- TrackerResponse{Err: err}
					close(req.Resp)
				}
				continue
			}
			if err := encoder.Encode(req.Hash); err != nil {
				log.Println("Error encoding file hash:", err)
				if req.Resp != nil {
					req.Resp <- TrackerResponse{Err: err}
					close(req.Resp)
				}
				continue
			}
			fmt.Printf("Server updated: %s - %s\n", req.Type, req.FilePath)
			if req.Resp != nil {
				req.Resp <- TrackerResponse{}
				close(req.Resp)
			}
		case "query":
			if err := encoder.Encode("query"); err != nil {
				log.Println("Error encoding request type:", err)
				if req.Resp != nil {
					req.Resp <- TrackerResponse{Err: err}
					close(req.Resp)
				}
				continue
			}
			if err := encoder.Encode(req.Hash); err != nil {
				log.Println("Error encoding hash:", err)
				if req.Resp != nil {
					req.Resp <- TrackerResponse{Err: err}
					close(req.Resp)
				}
				continue
			}
			var ips []string
			if err := decoder.Decode(&ips); err != nil {
				log.Println("Error decoding result:", err)
				if req.Resp != nil {
					req.Resp <- TrackerResponse{Err: err}
					close(req.Resp)
				}
				continue
			}
			fmt.Println("IPs for hash", req.Hash, ":", ips)
			if req.Resp != nil {
				req.Resp <- TrackerResponse{IPs: ips}
				close(req.Resp)
			}
		}
	}
}

func storeHashesViaChannel(reqChan chan<- TrackerRequest, hashes map[string][]int) {
	var hashList []int
	for _, v := range hashes {
		hashList = append(hashList, v...)
	}
	respChan := make(chan TrackerResponse, 1)
	reqChan <- TrackerRequest{Type: "store", StoreHashes: hashList, Resp: respChan}
	<-respChan
}

func updateServer(reqChan chan<- TrackerRequest, action string, filePath string, client *Client) {
	fileHash, err := sum(filePath)
	if err != nil {
		log.Printf("Error calculating hash for file %s: %v", filePath, err)
		fileHash = 0
	}
	if action == "create" {
		client.mu.Lock()
		client.hashMap[fileHash] = filePath
		client.mu.Unlock()
	}
	reqChan <- TrackerRequest{Type: action, Hash: fileHash, FilePath: filePath, Resp: nil}
	if action == "delete" {
		client.mu.Lock()
		delete(client.hashMap, fileHash)
		client.mu.Unlock()
	}
}

func monitorDirectory(reqChan chan<- TrackerRequest, directory string, server *Client) {
	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		log.Fatal(err)
	}
	defer watcher.Close()

	err = watcher.Add(directory)
	if err != nil {
		log.Fatal(err)
	}

	for {
		select {
		case event, ok := <-watcher.Events:
			if !ok {
				return
			}
			if event.Op&fsnotify.Create == fsnotify.Create {
				fmt.Println("File created:", event.Name)
				updateServer(reqChan, "create", event.Name, server)
			}
			if event.Op&fsnotify.Remove == fsnotify.Remove {
				fmt.Println("File deleted:", event.Name)
				updateServer(reqChan, "delete", event.Name, server)
			}
		case err, ok := <-watcher.Errors:
			if !ok {
				return
			}
			fmt.Println("Error:", err)
		}
	}
}

func queryHash(reqChan chan<- TrackerRequest, hash int) ([]string, error) {
	respChan := make(chan TrackerResponse, 1)
	reqChan <- TrackerRequest{Type: "query", Hash: hash, Resp: respChan}
	resp := <-respChan
	return resp.IPs, resp.Err
}

func (s *Client) handleDownloadRequest(conn net.Conn, decoder *gob.Decoder) {
	var fileHash int
	if err := decoder.Decode(&fileHash); err != nil {
		fmt.Println(err)
		log.Println("Error decoding file hash:", err)
		return
	}

	s.mu.RLock()
	filePath := s.hashMap[fileHash]
	filePathCopy := filePath
	s.mu.RUnlock()

	file, err := os.Open("./" + filePathCopy)
	if err != nil {
		fmt.Println("./" + filePathCopy)
		fmt.Println(err)
		log.Println("Error opening file:", err)
		return
	}
	defer file.Close()

	chunkData, err := io.ReadAll(file)
	if err != nil {
		fmt.Print(err)
		log.Println("Error reading chunk data:", err)
		return
	}

	encoder := gob.NewEncoder(conn)
	if err := encoder.Encode(chunkData); err != nil {
		fmt.Print(err)
		log.Println("Error encoding chunk data:", err)
		return
	}

	log.Printf("Chunk with hash %d sent successfully\n", fileHash)
}

func (s *Client) handleConnection(conn net.Conn) {
	defer conn.Close()

	for {
		var requestType string
		decoder := gob.NewDecoder(conn)
		if err := decoder.Decode(&requestType); err != nil {
			if err.Error() == "EOF" {
				log.Println("Client disconnected")
				return
			}
			log.Println("Error decoding request type:", err)
			return
		}

		switch requestType {
		case "download":
			s.handleDownloadRequest(conn, decoder)
		default:
			log.Println("Unknown request type:", requestType)
		}
	}
}

func startClientServer(clientPort string, server *Client) {
	ln, err := net.Listen("tcp", fmt.Sprintf(":%s", clientPort))
	if err != nil {
		log.Fatal(err)
	}
	defer ln.Close()

	fmt.Printf("Server is listening on port %s...\n", clientPort)

	for {
		conn, err := ln.Accept()
		if err != nil {
			log.Println("Error accepting connection:", err)
			continue
		}
		go server.handleConnection(conn)
	}
}

func download(peerPort string, hash int, ip string, outputPath string) error {
	conn, err := net.Dial("tcp", fmt.Sprintf("%s:%s", ip, peerPort))
	if err != nil {
		fmt.Print("error connecting: ")
		return fmt.Errorf("error connecting to server: %v", err)
	}
	defer conn.Close()

	encoder := gob.NewEncoder(conn)
	requestType := "download"
	if err := encoder.Encode(&requestType); err != nil {
		return fmt.Errorf("error sending request type: %v", err)
	}
	if err := encoder.Encode(&hash); err != nil {
		return fmt.Errorf("error sending file hash: %v", err)
	}

	decoder := gob.NewDecoder(conn)
	var chunkData []byte
	if err := decoder.Decode(&chunkData); err != nil {
		fmt.Printf("error receiving chunk data: %v", err)
		return fmt.Errorf("error receiving chunk data: %v", err)
	}

	if err := os.WriteFile(outputPath, chunkData, 0644); err != nil {
		return fmt.Errorf("error saving chunk to file: %v", err)
	}
	fmt.Printf("Chunk downloaded and saved to %s\n", outputPath)
	return nil
}

func main() {
	if len(os.Args) < 3 {
		panic("usage: go run main.go <client_port> <peer_port> <data_path>")
	}
	clientPort := os.Args[1]
	peerPort := os.Args[2]
	directory := os.Args[3]

	reader := bufio.NewReader(os.Stdin)
	fmt.Print("Enter server IP: ")
	serverIp, _ := reader.ReadString('\n')
	serverIp = strings.TrimSpace(serverIp)

	conn, err := net.Dial("tcp", serverIp+":8080")
	if err != nil {
		log.Fatal(err)
	}

	reqChan := make(chan TrackerRequest, 10)
	go runTrackerConnection(conn, reqChan)

	initialHashes, filePaths := generateFilesHashMap(directory)
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		storeHashesViaChannel(reqChan, initialHashes)
	}()
	wg.Wait()

	server := NewClient(filePaths)
	go monitorDirectory(reqChan, directory, server)
	go startClientServer(clientPort, server)

	for {
		fmt.Println("\nChoose an option:")
		fmt.Println("1. Query hash")
		fmt.Println("2. Download file")
		fmt.Println("3. Exit")
		fmt.Print("Enter choice (1, 2 or 3): ")

		choiceStr, err := reader.ReadString('\n')
		if err != nil {
			log.Fatal("Error reading input:", err)
		}
		choiceStr = strings.TrimSpace(choiceStr)
		choice, err := strconv.Atoi(choiceStr)
		if err != nil {
			log.Fatal("Invalid choice:", err)
		}

		switch choice {
		case 1:
			fmt.Print("Enter hash to query: ")
			hashInput, _ := reader.ReadString('\n')
			hashInput = strings.TrimSpace(hashInput)
			hash, err := strconv.Atoi(hashInput)
			if err != nil {
				log.Fatal("Invalid hash value:", err)
			}
			queryHash(reqChan, hash)

		case 2:
			fmt.Print("Enter hash to query: ")
			hashInput, _ := reader.ReadString('\n')
			hashInput = strings.TrimSpace(hashInput)
			hash, err := strconv.Atoi(hashInput)
			if err != nil {
				log.Fatal("Invalid hash value:", err)
			}

			fmt.Print("Enter file path to output: ")
			filePath, _ := reader.ReadString('\n')
			filePath = strings.TrimSpace(filePath)

			ips, err := queryHash(reqChan, hash)
			if err != nil {
				log.Fatal("Error while searching for IPs for the provided hash", err)
				continue
			}

			if len(ips) == 0 {
				fmt.Println("No IPs found for the provided hash.")
				continue
			}

			download(peerPort, hash, strings.Split(ips[0], ":")[0], filePath)

		case 3:
			fmt.Println("Exiting...")
			return

		default:
			fmt.Println("Invalid choice. Please enter 1, 2 or 3.")
		}
	}
}